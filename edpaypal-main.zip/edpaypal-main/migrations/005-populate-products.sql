INSERT INTO products 
VALUES 
  ('66a55a1d-2e99-4423-90fc-d67a47bc792e', 'Teclado mecánico', 'Teclado mecánico ideal para programadores', 'https://picsum.photos/seed/picsum/200/300', false, 0, 70, DEFAULT, NULL),
  ('10d20c7c-f861-4c0d-8e0f-e53c623412fd', 'Mouse inalámbrico', 'Mouse inalámbrico ideal para gamers', 'https://picsum.photos/seed/picsum/200/300', false, 0, 35, DEFAULT, NULL),
  ('2bc2de91-3bfc-4de9-ad1b-2a211943cb76', 'Monitor 4k', 'Monitor 4k ideal para gamers y programadores', 'https://picsum.photos/seed/picsum/200/300', false, 0, 300, DEFAULT, NULL),
  ('0b719332-8464-4618-b868-58d04dd58144', 'Escritorio ergonómico', 'Escritorio con altura configurable', 'https://picsum.photos/seed/picsum/200/300', false, 0, 350, DEFAULT, NULL),
  ('b94deaad-ee6d-422b-b2cd-0dbe967bc9d2', 'Suscripción Mensual', 'Suscribete y ten acceso a todo por un mes', 'https://picsum.photos/seed/picsum/200/300', true, 1, 30, DEFAULT, NULL),
  ('42483d38-3483-41d5-ba98-46dc2d749bfd', 'Suscripción Anual', 'Suscribete con acceso todo un año, ahorra 2 meses', 'https://picsum.photos/seed/picsum/200/300', true, 12, 300, DEFAULT, NULL);
